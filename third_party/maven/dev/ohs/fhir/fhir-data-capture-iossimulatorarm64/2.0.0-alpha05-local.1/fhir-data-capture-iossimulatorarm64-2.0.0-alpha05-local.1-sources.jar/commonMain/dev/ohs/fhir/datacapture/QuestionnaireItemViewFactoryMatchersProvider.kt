/*
 * Copyright 2025-2026 Open Health Stack Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dev.ohs.fhir.datacapture

/**
 * Provides the [QuestionnaireItemViewFactoryMatcher]s which are used to evaluate whether a custom
 * [dev.ohs.fhir.datacapture.views.factories.QuestionnaireItemViewFactory] should be used to render
 * a given questionnaire item.
 *
 * **NOTE**:
 *
 * User-provided custom views take precedence over canonical views provided by the library. If
 * multiple [QuestionnaireItemViewFactoryMatcher] are applicable for the same item, the behavior is
 * undefined (any of them may be selected).
 *
 * See the
 * [developer guide](https://github.com/google/android-fhir/wiki/SDCL:-Customize-how-a-Questionnaire-is-displayed#custom-questionnaire-components)
 * for more information.
 */
interface QuestionnaireItemViewFactoryMatchersProvider {
  /**
   * Implementation should specify when custom questionnaire components should be used.
   *
   * @return A [List] of [QuestionnaireItemViewFactoryMatcher]s which are used to evaluate whether a
   *   custom [dev.ohs.fhir.datacapture.views.factories.QuestionnaireItemViewFactory] should be used
   *   to render a given questionnaire item.
   */
  fun get(): List<QuestionnaireItemViewFactoryMatcher>
}
