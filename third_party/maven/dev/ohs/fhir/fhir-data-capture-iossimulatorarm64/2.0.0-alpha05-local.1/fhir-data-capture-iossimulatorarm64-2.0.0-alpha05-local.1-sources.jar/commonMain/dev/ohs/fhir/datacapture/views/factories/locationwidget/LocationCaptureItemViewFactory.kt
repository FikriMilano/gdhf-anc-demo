/*
 * Copyright 2026 Open Health Stack Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dev.ohs.fhir.datacapture.views.factories.locationwidget

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.jordond.compass.Priority
import dev.jordond.compass.geolocation.GeolocatorResult
import dev.ohs.fhir.datacapture.QuestionnaireItemViewFactoryMatcher
import dev.ohs.fhir.datacapture.extensions.itemControlCode
import dev.ohs.fhir.datacapture.extensions.itemMedia
import dev.ohs.fhir.datacapture.theme.QuestionnaireTheme
import dev.ohs.fhir.datacapture.views.QuestionnaireViewItem
import dev.ohs.fhir.datacapture.views.components.Header
import dev.ohs.fhir.datacapture.views.components.MediaItem
import dev.ohs.fhir.datacapture.views.factories.QuestionnaireItemViewFactory
import kotlin_fhir_data_capture.datacapture.generated.resources.Res
import kotlin_fhir_data_capture.datacapture.generated.resources.gm_location_on_24
import kotlin_fhir_data_capture.datacapture.generated.resources.record_gps_location
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

/**
 * Renders the "Record GPS Location" button for a questionnaire item with item control code
 * `location-widget`. Triggers a one-shot device location fetch and broadcasts the result via
 * [LocationEventBus]; does not display coordinate values itself.
 *
 * @see LocationCoordinateItemViewFactory for the read-only fields that display the captured
 *   coordinates.
 */
object LocationCaptureItemViewFactory : QuestionnaireItemViewFactory {

  @Composable
  override fun Content(questionnaireViewItem: QuestionnaireViewItem) {
    val coroutineScope = rememberCoroutineScope()
    val geolocator = rememberGeolocator()
    var isLoadingLocation by remember(questionnaireViewItem) { mutableStateOf(false) }
    var geolocatorError: String? by remember(questionnaireViewItem) { mutableStateOf(null) }

    Column(
      modifier =
        Modifier.fillMaxWidth()
          .padding(
            horizontal = QuestionnaireTheme.dimensions.itemMarginHorizontal,
            vertical = QuestionnaireTheme.dimensions.itemMarginVertical,
          ),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Header(questionnaireViewItem)

      questionnaireViewItem.questionnaireItem.itemMedia?.let { MediaItem(it) }

      TextButton(
        onClick = {
          isLoadingLocation = true
          coroutineScope.launch {
            val result = geolocator.current(priority = Priority.HighAccuracy)
            if (result is GeolocatorResult.Success) {
              geolocatorError = null
              val loc = result.data
              LocationEventBus.emit(
                LocationData(
                  latitude = loc.coordinates.latitude,
                  longitude = loc.coordinates.longitude,
                  altitude = loc.mslAltitude?.meters,
                )
              )
            } else if (result is GeolocatorResult.Error) {
              geolocatorError = result.message
              println("Location fetch failed: $geolocatorError")
            }

            isLoadingLocation = false
          }
        },
        enabled = !isLoadingLocation,
      ) {
        Icon(
          painter = painterResource(Res.drawable.gm_location_on_24),
          contentDescription = "Record GPS icon",
          modifier = Modifier.size(24.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(stringResource(Res.string.record_gps_location).uppercase())
        if (isLoadingLocation) {
          Spacer(modifier = Modifier.width(8.dp))
          CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
        }
      }

      if (!geolocatorError.isNullOrBlank()) {
        Text(
          text = geolocatorError!!,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.error,
          modifier = Modifier.padding(start = 12.dp),
        )
      }
    }
  }
}

val LocationCaptureItemViewFactoryMatcher =
  QuestionnaireItemViewFactoryMatcher(LocationCaptureItemViewFactory) {
    it.itemControlCode == "location-widget"
  }
