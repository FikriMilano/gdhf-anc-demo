/*
 * Copyright 2022-2026 Open Health Stack Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dev.ohs.fhir.datacapture

import dev.ohs.fhir.model.r4.Coding
import dev.ohs.fhir.model.r4.Resource
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds

/**
 * Configuration for the DataCapture library. Supply an instance via [LocalDataCaptureConfig]:
 * ```kotlin
 * CompositionLocalProvider(LocalDataCaptureConfig provides DataCaptureConfig(...)) {
 *   App()
 * }
 * ```
 */
data class DataCaptureConfig(
  /**
   * An [ExternalAnswerValueSetResolver] may be set to provide answer options dynamically for
   * `choice` and `open-choice` type questions.
   */
  val valueSetResolverExternal: ExternalAnswerValueSetResolver? = null,

  /**
   * A [XFhirQueryResolver] may be set by the client to resolve x-fhir-query for the library. See
   * https://build.fhir.org/ig/HL7/sdc/expressions.html#fhirquery for more details.
   */
  val xFhirQueryResolver: XFhirQueryResolver? = null,

  /** Resolves a URL to the media binary content. */
  val urlResolver: UrlResolver? = null,

  /**
   * A [QuestionnaireItemViewHolderFactoryMatchersProviderFactory] may be set by the client to
   * provide [QuestionnaireItemViewFactoryMatcher]s to add custom questionnaire components or
   * override the behaviour of existing components in the sdc.
   */
  val questionnaireItemView: QuestionnaireItemViewHolderFactoryMatchersProviderFactory? = null,

  /**
   * How long text input must settle before it is passed to the answer handler. Input arriving
   * within this window replaces the pending value instead of triggering a separate update, which
   * keeps validation and expression evaluation off the typing path.
   *
   * Set to [Duration.ZERO] to handle every change immediately.
   */
  val textInputDebounce: Duration = 500.milliseconds,
)

/**
 * Resolves external answer value sets not defined in the questionnaire's `contained` element. This
 * allows the library to render answer options to `choice` and `open-choice` type questions more
 * dynamically.
 *
 * NOTE: The result of the resolution may be cached to improve performance. In other words, the
 * resolver may be called only once after which the same answer value set may be used multiple times
 * in the UI to populate answer options.
 */
interface ExternalAnswerValueSetResolver {
  suspend fun resolve(uri: String): List<Coding>
}

/**
 * Resolves resources based on the provided xFhir query. This allows the library to resolve
 * x-fhir-query answer expressions.
 *
 * NOTE: The result of the resolution may be cached to improve performance. In other words, the
 * resolver may be called only once after which the Resources may be used multiple times in the UI.
 */
fun interface XFhirQueryResolver {
  suspend fun resolve(xFhirQuery: String): List<Resource>
}

/**
 * Resolves media content based on the provided URL, allowing the library to render media content in
 * its UI.
 */
interface UrlResolver {
  suspend fun resolveBitmapUrl(url: String): ByteArray?
}

/**
 * Factory to create [QuestionnaireItemViewFactoryMatchersProvider]to provide [List] of
 * [QuestionnaireItemViewFactoryMatcher]. The developers may provide the factory to the library via
 * [DataCaptureConfig] to add custom questionnaire components or override the behaviour of existing
 * components in the sdc.
 *
 * See the
 * [developer guide](https://github.com/google/android-fhir/wiki/SDCL:-Customize-how-a-Questionnaire-is-displayed#custom-questionnaire-components)
 * for more information.
 */
fun interface QuestionnaireItemViewHolderFactoryMatchersProviderFactory {
  fun get(provider: String): QuestionnaireItemViewFactoryMatchersProvider
}
