/*
 * Copyright 2025-2026 Open Health Stack Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dev.ohs.fhir.datacapture.views.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import dev.ohs.fhir.datacapture.views.QuestionnaireViewItem
import kotlin_fhir_data_capture.datacapture.generated.resources.Res
import kotlin_fhir_data_capture.datacapture.generated.resources.optional_helper_text
import kotlin_fhir_data_capture.datacapture.generated.resources.required
import org.jetbrains.compose.resources.stringResource

/**
 * Returns string identified by R.string.required if
 * [QuestionnaireViewItem.questionViewTextConfiguration.showRequiredText] and
 * [dev.ohs.fhir.model.r4.Questionnaire.Item.required] is true, or R.string.optional_text if
 * [QuestionnaireViewItem.questionViewTextConfiguration.showOptionalText] is true.
 */
@Composable
fun getRequiredOrOptionalText(questionnaireViewItem: QuestionnaireViewItem): String? {
  val requiredTextString = stringResource(Res.string.required)
  val optionalHelperTextString = stringResource(Res.string.optional_helper_text)

  return remember(questionnaireViewItem) {
    when {
      (questionnaireViewItem.questionnaireItem.required?.value == true &&
        questionnaireViewItem.questionViewTextConfiguration.showRequiredText) -> {
        requiredTextString
      }

      (questionnaireViewItem.questionnaireItem.required?.value != true &&
        questionnaireViewItem.questionViewTextConfiguration.showOptionalText) -> {
        optionalHelperTextString
      }

      else -> {
        null
      }
    }
  }
}
