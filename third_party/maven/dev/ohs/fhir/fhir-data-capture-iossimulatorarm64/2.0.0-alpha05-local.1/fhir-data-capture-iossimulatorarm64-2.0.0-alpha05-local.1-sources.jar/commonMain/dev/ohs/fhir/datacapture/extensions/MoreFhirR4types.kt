/*
 * Copyright 2025-2026 Open Health Stack Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dev.ohs.fhir.datacapture.extensions

import androidx.compose.ui.text.intl.Locale
import dev.ohs.fhir.model.r4.Coding
import dev.ohs.fhir.model.r4.Quantity

internal const val EXT_TRANSLATION = "http://hl7.org/fhir/StructureDefinition/translation"

internal fun dev.ohs.fhir.model.r4.String.getLocalizedText(
  lang: String = Locale.current.toLanguageTag()
): String? = getTranslation(lang) ?: getTranslation(lang.split("-").firstOrNull()) ?: value

internal fun dev.ohs.fhir.model.r4.String.getTranslation(l: String?): String? {
  for (e in extension) {
    if (e.url == EXT_TRANSLATION) {
      val langExtValue = e.readStringExtension("lang")
      if (langExtValue == l) return e.readStringExtension("content")
    }
  }
  return null
}

/**
 * Converts Quantity to Coding type. The resulting Coding properties are equivalent of Coding.system
 * = Quantity.system Coding.code = Quantity.code Coding.display = Quantity.unit
 */
internal fun Quantity.toCoding(): Coding =
  Coding(system = this.system, code = this.code, display = this.unit)

internal fun Coding.hasCode() = !this.code?.value.isNullOrBlank()

internal fun Coding.hasDisplay() = !this.display?.value.isNullOrBlank()

internal fun Coding.hasSystem() = !this.system?.value.isNullOrBlank()

internal fun Coding.hasVersion() = !this.version?.value.isNullOrBlank()

typealias FhirR4Boolean = dev.ohs.fhir.model.r4.Boolean

typealias FhirR4DateType = dev.ohs.fhir.model.r4.Date

typealias FhirR4Decimal = dev.ohs.fhir.model.r4.Decimal

typealias FhirR4Integer = dev.ohs.fhir.model.r4.Integer

typealias FhirR4String = dev.ohs.fhir.model.r4.String
