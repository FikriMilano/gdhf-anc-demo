@file:OptIn(InternalResourceApi::class)

package kotlin_fhir_data_capture.datacapture.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String =
    "composeResources/kotlin_fhir_data_capture.datacapture.generated.resources/"

@delegate:ResourceContentHash(771_627_711)
internal val Res.drawable.add_24px: DrawableResource by lazy {
      DrawableResource("drawable:add_24px", setOf(
        ResourceItem(setOf(), "${MD}drawable/add_24px.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_953_463_422)
internal val Res.drawable.delete_24px: DrawableResource by lazy {
      DrawableResource("drawable:delete_24px", setOf(
        ResourceItem(setOf(), "${MD}drawable/delete_24px.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_523_524_473)
internal val Res.drawable.edit_outlined_24dp: DrawableResource by lazy {
      DrawableResource("drawable:edit_outlined_24dp", setOf(
        ResourceItem(setOf(), "${MD}drawable/edit_outlined_24dp.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(59_263_433)
internal val Res.drawable.error_filled_24dp: DrawableResource by lazy {
      DrawableResource("drawable:error_filled_24dp", setOf(
        ResourceItem(setOf(), "${MD}drawable/error_filled_24dp.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(228_603_978)
internal val Res.drawable.gm_calendar_today_24: DrawableResource by lazy {
      DrawableResource("drawable:gm_calendar_today_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/gm_calendar_today_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-2_023_167_287)
internal val Res.drawable.gm_location_on_24: DrawableResource by lazy {
      DrawableResource("drawable:gm_location_on_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/gm_location_on_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(231_201_007)
internal val Res.drawable.gm_schedule_24: DrawableResource by lazy {
      DrawableResource("drawable:gm_schedule_24", setOf(
        ResourceItem(setOf(), "${MD}drawable/gm_schedule_24.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-731_833_200)
internal val Res.drawable.ic_access_time: DrawableResource by lazy {
      DrawableResource("drawable:ic_access_time", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_access_time.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_244_784_914)
internal val Res.drawable.ic_audio_file: DrawableResource by lazy {
      DrawableResource("drawable:ic_audio_file", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_audio_file.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(288_916_136)
internal val Res.drawable.ic_camera: DrawableResource by lazy {
      DrawableResource("drawable:ic_camera", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_camera.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-715_452_814)
internal val Res.drawable.ic_clear: DrawableResource by lazy {
      DrawableResource("drawable:ic_clear", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_clear.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_936_180_121)
internal val Res.drawable.ic_delete: DrawableResource by lazy {
      DrawableResource("drawable:ic_delete", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_delete.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_625_501_400)
internal val Res.drawable.ic_document_file: DrawableResource by lazy {
      DrawableResource("drawable:ic_document_file", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_document_file.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_068_971_255)
internal val Res.drawable.ic_file: DrawableResource by lazy {
      DrawableResource("drawable:ic_file", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_file.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_642_200_335)
internal val Res.drawable.ic_help: DrawableResource by lazy {
      DrawableResource("drawable:ic_help", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_help.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(424_052_348)
internal val Res.drawable.ic_image_file: DrawableResource by lazy {
      DrawableResource("drawable:ic_image_file", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_image_file.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(2_120_668_732)
internal val Res.drawable.ic_keyboard: DrawableResource by lazy {
      DrawableResource("drawable:ic_keyboard", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_keyboard.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_387_736_389)
internal val Res.drawable.ic_location_on: DrawableResource by lazy {
      DrawableResource("drawable:ic_location_on", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_location_on.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_070_170_506)
internal val Res.drawable.ic_video_file: DrawableResource by lazy {
      DrawableResource("drawable:ic_video_file", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_video_file.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_756_435_376)
internal val Res.drawable.warning_filled_24dp: DrawableResource by lazy {
      DrawableResource("drawable:warning_filled_24dp", setOf(
        ResourceItem(setOf(), "${MD}drawable/warning_filled_24dp.xml", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainDrawable0Resources(map: MutableMap<String, DrawableResource>) {
  map.put("add_24px", Res.drawable.add_24px)
  map.put("delete_24px", Res.drawable.delete_24px)
  map.put("edit_outlined_24dp", Res.drawable.edit_outlined_24dp)
  map.put("error_filled_24dp", Res.drawable.error_filled_24dp)
  map.put("gm_calendar_today_24", Res.drawable.gm_calendar_today_24)
  map.put("gm_location_on_24", Res.drawable.gm_location_on_24)
  map.put("gm_schedule_24", Res.drawable.gm_schedule_24)
  map.put("ic_access_time", Res.drawable.ic_access_time)
  map.put("ic_audio_file", Res.drawable.ic_audio_file)
  map.put("ic_camera", Res.drawable.ic_camera)
  map.put("ic_clear", Res.drawable.ic_clear)
  map.put("ic_delete", Res.drawable.ic_delete)
  map.put("ic_document_file", Res.drawable.ic_document_file)
  map.put("ic_file", Res.drawable.ic_file)
  map.put("ic_help", Res.drawable.ic_help)
  map.put("ic_image_file", Res.drawable.ic_image_file)
  map.put("ic_keyboard", Res.drawable.ic_keyboard)
  map.put("ic_location_on", Res.drawable.ic_location_on)
  map.put("ic_video_file", Res.drawable.ic_video_file)
  map.put("warning_filled_24dp", Res.drawable.warning_filled_24dp)
}
