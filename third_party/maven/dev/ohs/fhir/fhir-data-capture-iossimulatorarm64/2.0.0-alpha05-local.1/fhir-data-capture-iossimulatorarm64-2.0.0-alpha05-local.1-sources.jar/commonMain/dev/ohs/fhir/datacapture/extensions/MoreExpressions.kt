/*
 * Copyright 2022-2026 Open Health Stack Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dev.ohs.fhir.datacapture.extensions

import dev.ohs.fhir.model.r4.Expression

internal val Expression.isXFhirQuery: Boolean
  get() = Expression.ExpressionLanguage.Application_X_Fhir_Query.code == this.language.code

internal val Expression.isFhirPath: Boolean
  get() = Expression.ExpressionLanguage.Text_Fhirpath.code == this.language.code
