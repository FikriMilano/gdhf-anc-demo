@file:OptIn(InternalResourceApi::class)

package kotlin_fhir_data_capture.datacapture.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String =
    "composeResources/kotlin_fhir_data_capture.datacapture.generated.resources/"

@delegate:ResourceContentHash(1_347_399_210)
internal val Res.string.add_repeated_group_item: StringResource by lazy {
      StringResource("string:add_repeated_group_item", "add_repeated_group_item", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 43),
      ))
    }

@delegate:ResourceContentHash(259_850_602)
internal val Res.string.audio_deleted: StringResource by lazy {
      StringResource("string:audio_deleted", "audio_deleted", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 54, 41),
      ))
    }

@delegate:ResourceContentHash(2_050_306_276)
internal val Res.string.audio_uploaded: StringResource by lazy {
      StringResource("string:audio_uploaded", "audio_uploaded", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 96, 42),
      ))
    }

@delegate:ResourceContentHash(-507_690_378)
internal val Res.string.back_button_text: StringResource by lazy {
      StringResource("string:back_button_text", "back_button_text", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 139, 32),
      ))
    }

@delegate:ResourceContentHash(834_007_092)
internal val Res.string.button_pagination_next: StringResource by lazy {
      StringResource("string:button_pagination_next", "button_pagination_next", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 172, 38),
      ))
    }

@delegate:ResourceContentHash(1_901_951_372)
internal val Res.string.button_pagination_previous: StringResource by lazy {
      StringResource("string:button_pagination_previous", "button_pagination_previous", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 211, 46),
      ))
    }

@delegate:ResourceContentHash(-1_720_064_377)
internal val Res.string.button_review: StringResource by lazy {
      StringResource("string:button_review", "button_review", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 258, 29),
      ))
    }

@delegate:ResourceContentHash(-1_320_945_082)
internal val Res.string.cancel: StringResource by lazy {
      StringResource("string:cancel", "cancel", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 325, 22),
      ))
    }

@delegate:ResourceContentHash(-1_320_945_082)
internal val Res.string.cancel_questionnaire: StringResource by lazy {
      StringResource("string:cancel_questionnaire", "cancel_questionnaire", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 288, 36),
      ))
    }

@delegate:ResourceContentHash(1_696_386_904)
internal val Res.string.cd_file_icon_preview: StringResource by lazy {
      StringResource("string:cd_file_icon_preview", "cd_file_icon_preview", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 348, 52),
      ))
    }

@delegate:ResourceContentHash(-714_123_293)
internal val Res.string.cd_photo_preview: StringResource by lazy {
      StringResource("string:cd_photo_preview", "cd_photo_preview", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 401, 44),
      ))
    }

@delegate:ResourceContentHash(1_815_909_174)
internal val Res.string.date: StringResource by lazy {
      StringResource("string:date", "date", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 543, 20),
      ))
    }

@delegate:ResourceContentHash(965_788_620)
internal val Res.string.date_format_validation_error_msg: StringResource by lazy {
      StringResource("string:date_format_validation_error_msg", "date_format_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 446, 96),
      ))
    }

@delegate:ResourceContentHash(-224_832_944)
internal val Res.string.decimal_format_validation_error_msg: StringResource by lazy {
      StringResource("string:decimal_format_validation_error_msg", "decimal_format_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 564, 63),
      ))
    }

@delegate:ResourceContentHash(-1_959_108_374)
internal val Res.string.delete: StringResource by lazy {
      StringResource("string:delete", "delete", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 628, 22),
      ))
    }

@delegate:ResourceContentHash(-760_963_424)
internal val Res.string.edit_button_text: StringResource by lazy {
      StringResource("string:edit_button_text", "edit_button_text", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 651, 32),
      ))
    }

@delegate:ResourceContentHash(839_113_325)
internal val Res.string.file_deleted: StringResource by lazy {
      StringResource("string:file_deleted", "file_deleted", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 684, 36),
      ))
    }

@delegate:ResourceContentHash(127_057_291)
internal val Res.string.file_uploaded: StringResource by lazy {
      StringResource("string:file_uploaded", "file_uploaded", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 721, 41),
      ))
    }

@delegate:ResourceContentHash(1_194_913_771)
internal val Res.string.group_header_add_item_button: StringResource by lazy {
      StringResource("string:group_header_add_item_button", "group_header_add_item_button", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 763, 48),
      ))
    }

@delegate:ResourceContentHash(-216_052_721)
internal val Res.string.help: StringResource by lazy {
      StringResource("string:help", "help", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 812, 20),
      ))
    }

@delegate:ResourceContentHash(2_343_909)
internal val Res.string.hyphen: StringResource by lazy {
      StringResource("string:hyphen", "hyphen", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 833, 18),
      ))
    }

@delegate:ResourceContentHash(611_282_542)
internal val Res.string.image_deleted: StringResource by lazy {
      StringResource("string:image_deleted", "image_deleted", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 852, 41),
      ))
    }

@delegate:ResourceContentHash(-1_893_229_080)
internal val Res.string.image_uploaded: StringResource by lazy {
      StringResource("string:image_uploaded", "image_uploaded", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 894, 42),
      ))
    }

@delegate:ResourceContentHash(1_866_030_800)
internal val Res.string.integer_format_validation_error_msg: StringResource by lazy {
      StringResource("string:integer_format_validation_error_msg", "integer_format_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 937, 91),
      ))
    }

@delegate:ResourceContentHash(-586_050_058)
internal val Res.string.loading: StringResource by lazy {
      StringResource("string:loading", "loading", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1029, 31),
      ))
    }

@delegate:ResourceContentHash(1_222_248_600)
internal val Res.string.max_decimal_validation_error_msg: StringResource by lazy {
      StringResource("string:max_decimal_validation_error_msg", "max_decimal_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1061, 148),
      ))
    }

@delegate:ResourceContentHash(202_422_707)
internal val Res.string.max_size_file_above_limit_validation_error_msg: StringResource by lazy {
      StringResource("string:max_size_file_above_limit_validation_error_msg", "max_size_file_above_limit_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1210, 106),
      ))
    }

@delegate:ResourceContentHash(1_484_138_001)
internal val Res.string.max_size_image_above_limit_validation_error_msg: StringResource by lazy {
      StringResource("string:max_size_image_above_limit_validation_error_msg", "max_size_image_above_limit_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1317, 111),
      ))
    }

@delegate:ResourceContentHash(332_951_013)
internal val Res.string.max_value_validation_error_msg: StringResource by lazy {
      StringResource("string:max_value_validation_error_msg", "max_value_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1429, 78),
      ))
    }

@delegate:ResourceContentHash(516_506_945)
internal val Res.string.media_not_saved_validation_error_msg: StringResource by lazy {
      StringResource("string:media_not_saved_validation_error_msg", "media_not_saved_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1508, 76),
      ))
    }

@delegate:ResourceContentHash(-1_610_130_360)
internal val Res.string.mime_type_wrong_media_format_validation_error_msg: StringResource by lazy {
      StringResource("string:mime_type_wrong_media_format_validation_error_msg", "mime_type_wrong_media_format_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1585, 93),
      ))
    }

@delegate:ResourceContentHash(-2_133_873_585)
internal val Res.string.min_length_validation_error_msg: StringResource by lazy {
      StringResource("string:min_length_validation_error_msg", "min_length_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1679, 143),
      ))
    }

@delegate:ResourceContentHash(1_309_951_813)
internal val Res.string.min_value_less_than_max_value_validation_error_msg: StringResource by lazy {
      StringResource("string:min_value_less_than_max_value_validation_error_msg", "min_value_less_than_max_value_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1823, 130),
      ))
    }

@delegate:ResourceContentHash(-2_085_068_480)
internal val Res.string.min_value_validation_error_msg: StringResource by lazy {
      StringResource("string:min_value_validation_error_msg", "min_value_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1954, 78),
      ))
    }

@delegate:ResourceContentHash(-834_165_101)
internal val Res.string.multi_select_dialog_subtitle: StringResource by lazy {
      StringResource("string:multi_select_dialog_subtitle", "multi_select_dialog_subtitle", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2033, 64),
      ))
    }

@delegate:ResourceContentHash(2_608_990)
internal val Res.string.no: StringResource by lazy {
      StringResource("string:no", "no", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2139, 14),
      ))
    }

@delegate:ResourceContentHash(1_530_106_128)
internal val Res.string.not_answered: StringResource by lazy {
      StringResource("string:not_answered", "not_answered", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2098, 40),
      ))
    }

@delegate:ResourceContentHash(-123_333_490)
internal val Res.string.number_format_validation_error_msg: StringResource by lazy {
      StringResource("string:number_format_validation_error_msg", "number_format_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2154, 146),
      ))
    }

@delegate:ResourceContentHash(2_554_120)
internal val Res.string.ok: StringResource by lazy {
      StringResource("string:ok", "ok", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2301, 14),
      ))
    }

@delegate:ResourceContentHash(838_096_846)
internal val Res.string.open_choice_other: StringResource by lazy {
      StringResource("string:open_choice_other", "open_choice_other", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2437, 33),
      ))
    }

@delegate:ResourceContentHash(-1_277_477_654)
internal val Res.string.open_choice_other_add_another: StringResource by lazy {
      StringResource("string:open_choice_other_add_another", "open_choice_other_add_another", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2316, 61),
      ))
    }

@delegate:ResourceContentHash(2_090_607_174)
internal val Res.string.open_choice_other_hint: StringResource by lazy {
      StringResource("string:open_choice_other_hint", "open_choice_other_hint", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2378, 58),
      ))
    }

@delegate:ResourceContentHash(-1_240_678_141)
internal val Res.string.optional_helper_text: StringResource by lazy {
      StringResource("string:optional_helper_text", "optional_helper_text", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2471, 40),
      ))
    }

@delegate:ResourceContentHash(272_412_451)
internal val Res.string.questionnaire_cancel_text: StringResource by lazy {
      StringResource("string:questionnaire_cancel_text", "questionnaire_cancel_text", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2512, 85),
      ))
    }

@delegate:ResourceContentHash(756_594_571)
internal val Res.string.questionnaire_review_mode_title: StringResource by lazy {
      StringResource("string:questionnaire_review_mode_title", "questionnaire_review_mode_title", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2598, 83),
      ))
    }

@delegate:ResourceContentHash(-231_665_837)
internal val Res.string.questionnaire_validation_error_fix_button_text: StringResource by lazy {
      StringResource("string:questionnaire_validation_error_fix_button_text", "questionnaire_validation_error_fix_button_text", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2682, 74),
      ))
    }

@delegate:ResourceContentHash(-152_407_687)
internal val Res.string.questionnaire_validation_error_headline: StringResource by lazy {
      StringResource("string:questionnaire_validation_error_headline", "questionnaire_validation_error_headline", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2757, 63),
      ))
    }

@delegate:ResourceContentHash(-305_515_092)
internal val Res.string.questionnaire_validation_error_item_text_with_bullet: StringResource by
    lazy {
      StringResource("string:questionnaire_validation_error_item_text_with_bullet", "questionnaire_validation_error_item_text_with_bullet", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2821, 72),
      ))
    }

@delegate:ResourceContentHash(-840_973_798)
internal val Res.string.questionnaire_validation_error_submit_button_text: StringResource by lazy {
      StringResource("string:questionnaire_validation_error_submit_button_text", "questionnaire_validation_error_submit_button_text", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2894, 77),
      ))
    }

@delegate:ResourceContentHash(-1_363_294_624)
internal val Res.string.questionnaire_validation_error_supporting_text: StringResource by lazy {
      StringResource("string:questionnaire_validation_error_supporting_text", "questionnaire_validation_error_supporting_text", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2972, 94),
      ))
    }

@delegate:ResourceContentHash(-265_742_062)
internal val Res.string.record_gps_location: StringResource by lazy {
      StringResource("string:record_gps_location", "record_gps_location", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3067, 55),
      ))
    }

@delegate:ResourceContentHash(829_629_213)
internal val Res.string.regex_validation_error_msg: StringResource by lazy {
      StringResource("string:regex_validation_error_msg", "regex_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3123, 102),
      ))
    }

@delegate:ResourceContentHash(-952_504_999)
internal val Res.string.repeated_group_title: StringResource by lazy {
      StringResource("string:repeated_group_title", "repeated_group_title", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3226, 44),
      ))
    }

@delegate:ResourceContentHash(-781_291_293)
internal val Res.string.required: StringResource by lazy {
      StringResource("string:required", "required", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3415, 28),
      ))
    }

@delegate:ResourceContentHash(1_919_399_164)
internal val Res.string.required_constraint_validation_error_msg: StringResource by lazy {
      StringResource("string:required_constraint_validation_error_msg", "required_constraint_validation_error_msg", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3271, 96),
      ))
    }

@delegate:ResourceContentHash(-781_291_279)
internal val Res.string.required_text_and_new_line: StringResource by lazy {
      StringResource("string:required_text_and_new_line", "required_text_and_new_line", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3368, 46),
      ))
    }

@delegate:ResourceContentHash(504_500_615)
internal val Res.string.review_answers_text: StringResource by lazy {
      StringResource("string:review_answers_text", "review_answers_text", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3444, 47),
      ))
    }

@delegate:ResourceContentHash(1_293_511_808)
internal val Res.string.save: StringResource by lazy {
      StringResource("string:save", "save", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3492, 20),
      ))
    }

@delegate:ResourceContentHash(-571_543_080)
internal val Res.string.select_date: StringResource by lazy {
      StringResource("string:select_date", "select_date", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3513, 35),
      ))
    }

@delegate:ResourceContentHash(323_304_563)
internal val Res.string.select_time: StringResource by lazy {
      StringResource("string:select_time", "select_time", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3549, 35),
      ))
    }

@delegate:ResourceContentHash(2_242_632)
internal val Res.string.space_asterisk: StringResource by lazy {
      StringResource("string:space_asterisk", "space_asterisk", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3585, 26),
      ))
    }

@delegate:ResourceContentHash(-1_604_846_198)
internal val Res.string.submit_questionnaire: StringResource by lazy {
      StringResource("string:submit_questionnaire", "submit_questionnaire", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3612, 36),
      ))
    }

@delegate:ResourceContentHash(712_875_278)
internal val Res.string.switch_to_clock_input: StringResource by lazy {
      StringResource("string:switch_to_clock_input", "switch_to_clock_input", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3649, 57),
      ))
    }

@delegate:ResourceContentHash(-1_801_119_493)
internal val Res.string.switch_to_text_input: StringResource by lazy {
      StringResource("string:switch_to_text_input", "switch_to_text_input", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3707, 56),
      ))
    }

@delegate:ResourceContentHash(-145_961_225)
internal val Res.string.take_photo: StringResource by lazy {
      StringResource("string:take_photo", "take_photo", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3764, 34),
      ))
    }

@delegate:ResourceContentHash(1_347_923_088)
internal val Res.string.time: StringResource by lazy {
      StringResource("string:time", "time", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3799, 20),
      ))
    }

@delegate:ResourceContentHash(828_768_998)
internal val Res.string.upload_audio: StringResource by lazy {
      StringResource("string:upload_audio", "upload_audio", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3820, 36),
      ))
    }

@delegate:ResourceContentHash(-238_619_496)
internal val Res.string.upload_document: StringResource by lazy {
      StringResource("string:upload_document", "upload_document", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3857, 43),
      ))
    }

@delegate:ResourceContentHash(-1_961_147_227)
internal val Res.string.upload_failed: StringResource by lazy {
      StringResource("string:upload_failed", "upload_failed", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3901, 41),
      ))
    }

@delegate:ResourceContentHash(1_459_771_399)
internal val Res.string.upload_file: StringResource by lazy {
      StringResource("string:upload_file", "upload_file", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3943, 35),
      ))
    }

@delegate:ResourceContentHash(1_659_232_679)
internal val Res.string.upload_photo: StringResource by lazy {
      StringResource("string:upload_photo", "upload_photo", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 3979, 36),
      ))
    }

@delegate:ResourceContentHash(-1_947_930_456)
internal val Res.string.upload_video: StringResource by lazy {
      StringResource("string:upload_video", "upload_video", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4016, 36),
      ))
    }

@delegate:ResourceContentHash(-257_683_407)
internal val Res.string.uploaded: StringResource by lazy {
      StringResource("string:uploaded", "uploaded", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4053, 28),
      ))
    }

@delegate:ResourceContentHash(774_673_323)
internal val Res.string.video_deleted: StringResource by lazy {
      StringResource("string:video_deleted", "video_deleted", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4082, 41),
      ))
    }

@delegate:ResourceContentHash(-1_729_838_299)
internal val Res.string.video_uploaded: StringResource by lazy {
      StringResource("string:video_uploaded", "video_uploaded", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4124, 42),
      ))
    }

@delegate:ResourceContentHash(2_678_212)
internal val Res.string.yes: StringResource by lazy {
      StringResource("string:yes", "yes", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 4167, 15),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("add_repeated_group_item", Res.string.add_repeated_group_item)
  map.put("audio_deleted", Res.string.audio_deleted)
  map.put("audio_uploaded", Res.string.audio_uploaded)
  map.put("back_button_text", Res.string.back_button_text)
  map.put("button_pagination_next", Res.string.button_pagination_next)
  map.put("button_pagination_previous", Res.string.button_pagination_previous)
  map.put("button_review", Res.string.button_review)
  map.put("cancel", Res.string.cancel)
  map.put("cancel_questionnaire", Res.string.cancel_questionnaire)
  map.put("cd_file_icon_preview", Res.string.cd_file_icon_preview)
  map.put("cd_photo_preview", Res.string.cd_photo_preview)
  map.put("date", Res.string.date)
  map.put("date_format_validation_error_msg", Res.string.date_format_validation_error_msg)
  map.put("decimal_format_validation_error_msg", Res.string.decimal_format_validation_error_msg)
  map.put("delete", Res.string.delete)
  map.put("edit_button_text", Res.string.edit_button_text)
  map.put("file_deleted", Res.string.file_deleted)
  map.put("file_uploaded", Res.string.file_uploaded)
  map.put("group_header_add_item_button", Res.string.group_header_add_item_button)
  map.put("help", Res.string.help)
  map.put("hyphen", Res.string.hyphen)
  map.put("image_deleted", Res.string.image_deleted)
  map.put("image_uploaded", Res.string.image_uploaded)
  map.put("integer_format_validation_error_msg", Res.string.integer_format_validation_error_msg)
  map.put("loading", Res.string.loading)
  map.put("max_decimal_validation_error_msg", Res.string.max_decimal_validation_error_msg)
  map.put("max_size_file_above_limit_validation_error_msg", Res.string.max_size_file_above_limit_validation_error_msg)
  map.put("max_size_image_above_limit_validation_error_msg", Res.string.max_size_image_above_limit_validation_error_msg)
  map.put("max_value_validation_error_msg", Res.string.max_value_validation_error_msg)
  map.put("media_not_saved_validation_error_msg", Res.string.media_not_saved_validation_error_msg)
  map.put("mime_type_wrong_media_format_validation_error_msg", Res.string.mime_type_wrong_media_format_validation_error_msg)
  map.put("min_length_validation_error_msg", Res.string.min_length_validation_error_msg)
  map.put("min_value_less_than_max_value_validation_error_msg", Res.string.min_value_less_than_max_value_validation_error_msg)
  map.put("min_value_validation_error_msg", Res.string.min_value_validation_error_msg)
  map.put("multi_select_dialog_subtitle", Res.string.multi_select_dialog_subtitle)
  map.put("no", Res.string.no)
  map.put("not_answered", Res.string.not_answered)
  map.put("number_format_validation_error_msg", Res.string.number_format_validation_error_msg)
  map.put("ok", Res.string.ok)
  map.put("open_choice_other", Res.string.open_choice_other)
  map.put("open_choice_other_add_another", Res.string.open_choice_other_add_another)
  map.put("open_choice_other_hint", Res.string.open_choice_other_hint)
  map.put("optional_helper_text", Res.string.optional_helper_text)
  map.put("questionnaire_cancel_text", Res.string.questionnaire_cancel_text)
  map.put("questionnaire_review_mode_title", Res.string.questionnaire_review_mode_title)
  map.put("questionnaire_validation_error_fix_button_text", Res.string.questionnaire_validation_error_fix_button_text)
  map.put("questionnaire_validation_error_headline", Res.string.questionnaire_validation_error_headline)
  map.put("questionnaire_validation_error_item_text_with_bullet", Res.string.questionnaire_validation_error_item_text_with_bullet)
  map.put("questionnaire_validation_error_submit_button_text", Res.string.questionnaire_validation_error_submit_button_text)
  map.put("questionnaire_validation_error_supporting_text", Res.string.questionnaire_validation_error_supporting_text)
  map.put("record_gps_location", Res.string.record_gps_location)
  map.put("regex_validation_error_msg", Res.string.regex_validation_error_msg)
  map.put("repeated_group_title", Res.string.repeated_group_title)
  map.put("required", Res.string.required)
  map.put("required_constraint_validation_error_msg", Res.string.required_constraint_validation_error_msg)
  map.put("required_text_and_new_line", Res.string.required_text_and_new_line)
  map.put("review_answers_text", Res.string.review_answers_text)
  map.put("save", Res.string.save)
  map.put("select_date", Res.string.select_date)
  map.put("select_time", Res.string.select_time)
  map.put("space_asterisk", Res.string.space_asterisk)
  map.put("submit_questionnaire", Res.string.submit_questionnaire)
  map.put("switch_to_clock_input", Res.string.switch_to_clock_input)
  map.put("switch_to_text_input", Res.string.switch_to_text_input)
  map.put("take_photo", Res.string.take_photo)
  map.put("time", Res.string.time)
  map.put("upload_audio", Res.string.upload_audio)
  map.put("upload_document", Res.string.upload_document)
  map.put("upload_failed", Res.string.upload_failed)
  map.put("upload_file", Res.string.upload_file)
  map.put("upload_photo", Res.string.upload_photo)
  map.put("upload_video", Res.string.upload_video)
  map.put("uploaded", Res.string.uploaded)
  map.put("video_deleted", Res.string.video_deleted)
  map.put("video_uploaded", Res.string.video_uploaded)
  map.put("yes", Res.string.yes)
}
