/*
 * Copyright 2025-2026 Open Health Stack Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dev.ohs.fhir.datacapture.extensions

import dev.ohs.fhir.datacapture.UrlResolver
import dev.ohs.fhir.model.r4.Attachment
import dev.ohs.fhir.model.r4.Base64Binary
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

internal suspend fun Attachment.imageData(urlResolver: UrlResolver?): ByteArray? {
  check(mimeType == MimeType.IMAGE.value) {
    "${mimeType?.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }} attachment is not supported in Item Media extension yet"
  }

  return data?.data ?: url?.value?.let { urlResolver?.resolveBitmapUrl(it) }
}

/** Returns the main MIME type of a MIME type string (e.g. image/png returns image). */
internal val Attachment.mimeType: String?
  get() = contentType?.value?.substringBefore("/")

@OptIn(ExperimentalEncodingApi::class)
internal val Base64Binary.data: ByteArray?
  get() = value?.let { Base64.decode(it) }
