/*
 * Copyright 2022-2026 Open Health Stack Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dev.ohs.fhir.datacapture.views.factories

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import dev.ohs.fhir.datacapture.extensions.FhirR4Integer
import dev.ohs.fhir.datacapture.extensions.itemMedia
import dev.ohs.fhir.datacapture.extensions.sliderStepValue
import dev.ohs.fhir.datacapture.theme.QuestionnaireTheme
import dev.ohs.fhir.datacapture.validation.Invalid
import dev.ohs.fhir.datacapture.validation.NotValidated
import dev.ohs.fhir.datacapture.validation.Valid
import dev.ohs.fhir.datacapture.validation.ValidationResult
import dev.ohs.fhir.datacapture.views.QuestionnaireViewItem
import dev.ohs.fhir.datacapture.views.components.ErrorText
import dev.ohs.fhir.datacapture.views.components.Header
import dev.ohs.fhir.datacapture.views.components.MediaItem
import dev.ohs.fhir.datacapture.views.components.SliderItem
import dev.ohs.fhir.model.r4.Extension
import dev.ohs.fhir.model.r4.QuestionnaireResponse
import kotlin_fhir_data_capture.datacapture.generated.resources.Res
import kotlin_fhir_data_capture.datacapture.generated.resources.min_value_less_than_max_value_validation_error_msg
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource

internal object SliderViewFactory : QuestionnaireItemViewFactory {
  private const val SLIDER_DEFAULT_STEP_SIZE = 1
  private const val SLIDER_DEFAULT_VALUE_FROM = 0.0F
  private const val SLIDER_DEFAULT_VALUE_TO = 100.0F

  @Composable
  override fun Content(questionnaireViewItem: QuestionnaireViewItem) {
    val validationMessage =
      remember(questionnaireViewItem) {
        displayValidationResult(questionnaireViewItem.validationResult)
      }
    val readOnly =
      remember(questionnaireViewItem) {
        questionnaireViewItem.questionnaireItem.readOnly?.value ?: false
      }
    val answer = remember(questionnaireViewItem) { questionnaireViewItem.answers.singleOrNull() }
    val minValue =
      remember(answer) {
        getExtensionValueFloat(
          questionnaireViewItem.minAnswerValue,
          default = SLIDER_DEFAULT_VALUE_FROM,
        )
      }
    val maxValue =
      remember(answer) {
        getExtensionValueFloat(
          questionnaireViewItem.maxAnswerValue,
          default = SLIDER_DEFAULT_VALUE_TO,
        )
      }

    check(minValue < maxValue) {
      stringResource(
        Res.string.min_value_less_than_max_value_validation_error_msg,
        minValue,
        maxValue,
      )
    }
    val stepSize =
      remember(questionnaireViewItem) {
        questionnaireViewItem.questionnaireItem.sliderStepValue ?: SLIDER_DEFAULT_STEP_SIZE
      }
    val steps =
      remember(stepSize, minValue, maxValue) { (maxValue - minValue).div(stepSize).toInt() - 1 }
    val questionnaireViewItemAnswerValue =
      remember(answer) { answer?.value?.asInteger()?.value?.value?.toFloat() ?: minValue }
    val coroutineScope = rememberCoroutineScope()

    Column(
      modifier =
        Modifier.fillMaxWidth()
          .padding(
            horizontal = QuestionnaireTheme.dimensions.itemMarginHorizontal,
            vertical = QuestionnaireTheme.dimensions.itemMarginVertical,
          )
    ) {
      Header(questionnaireViewItem, showRequiredOrOptionalText = true)
      questionnaireViewItem.questionnaireItem.itemMedia?.let { MediaItem(it) }
      SliderItem(
        position = questionnaireViewItemAnswerValue,
        steps = steps,
        valueRange = minValue..maxValue,
        enabled = !readOnly,
      ) {
        coroutineScope.launch {
          questionnaireViewItem.setAnswer(
            QuestionnaireResponse.Item.Answer(
              value =
                QuestionnaireResponse.Item.Answer.Value.Integer(FhirR4Integer(value = it.toInt()))
            )
          )
        }
      }
      validationMessage?.let { ErrorText(it) }
    }
  }

  private fun displayValidationResult(validationResult: ValidationResult) =
    when (validationResult) {
      is NotValidated,
      Valid -> null

      is Invalid -> validationResult.singleStringValidationMessage
    }

  private fun getExtensionValueFloat(extensionValue: Extension.Value?, default: Float) =
    extensionValue?.let {
      when (it) {
        is Extension.Value.Decimal -> it.value.value?.asBigDecimal()?.floatValue()
        is Extension.Value.Integer -> it.value.value?.toFloat()
        else -> throw IllegalArgumentException("Unexpected Extension.value: $extensionValue")
      }
    } ?: default
}
