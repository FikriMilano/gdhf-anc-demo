/*
 * Copyright 2022-2026 Open Health Stack Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dev.ohs.fhir.datacapture.views.factories

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.ohs.fhir.datacapture.LocalDataCaptureConfig
import dev.ohs.fhir.datacapture.extensions.itemMedia
import dev.ohs.fhir.datacapture.extensions.localizedFlyoverAnnotatedString
import dev.ohs.fhir.datacapture.extensions.unit
import dev.ohs.fhir.datacapture.validation.Invalid
import dev.ohs.fhir.datacapture.views.QuestionnaireViewItem
import dev.ohs.fhir.datacapture.views.components.EditTextFieldItem
import dev.ohs.fhir.datacapture.views.components.EditTextFieldState
import dev.ohs.fhir.datacapture.views.components.Header
import dev.ohs.fhir.datacapture.views.components.MediaItem
import dev.ohs.fhir.datacapture.views.components.UnitText
import dev.ohs.fhir.datacapture.views.components.getRequiredOrOptionalText
import dev.ohs.fhir.datacapture.views.components.questionLabel
import kotlin_fhir_data_capture.datacapture.generated.resources.Res
import kotlin_fhir_data_capture.datacapture.generated.resources.required_text_and_new_line
import org.jetbrains.compose.resources.StringResource
import org.jetbrains.compose.resources.stringResource

class TextInputFactory(
  private val keyboardOptions: KeyboardOptions,
  private val uiInputText: (QuestionnaireViewItem) -> String?,
  private val handleInput: suspend (String, QuestionnaireViewItem) -> Unit,
  private val isMultiLine: Boolean = false,
  private val validationMessageStringRes: StringResource,
  private val validationMessageStringResArgs: Array<Any> = emptyArray(),
) : QuestionnaireItemViewFactory {

  @Composable
  override fun Content(questionnaireViewItem: QuestionnaireViewItem) {
    val text = uiInputText(questionnaireViewItem) ?: ""
    val coroutineScope = rememberCoroutineScope()
    val requiredOptionalText = getRequiredOrOptionalText(questionnaireViewItem)
    val validationMessage = getValidationErrorMessage(questionnaireViewItem)
    val textInputDebounce = LocalDataCaptureConfig.current.textInputDebounce
    val composeViewQuestionnaireState =
      remember(questionnaireViewItem, textInputDebounce) {
        EditTextFieldState(
          initialInputText = text,
          handleTextInputChange = { handleInput(it, questionnaireViewItem) },
          coroutineScope = coroutineScope,
          debounce = textInputDebounce,
          hint = questionnaireViewItem.enabledDisplayItems.localizedFlyoverAnnotatedString,
          helperText = validationMessage.takeIf { !it.isNullOrBlank() } ?: requiredOptionalText,
          isError = !validationMessage.isNullOrBlank(),
          isReadOnly = questionnaireViewItem.questionnaireItem.readOnly?.value == true,
          keyboardOptions = keyboardOptions,
          isMultiLine = isMultiLine,
        )
      }
    val unit =
      remember(questionnaireViewItem) { questionnaireViewItem.questionnaireItem.unit?.code }

    val questionnaireItem = questionnaireViewItem.questionnaireItem

    Column(modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) {
      Header(questionnaireViewItem)

      questionnaireItem.itemMedia?.let { MediaItem(it) }

      Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        EditTextFieldItem(
          modifier = Modifier.weight(1f).questionLabel(questionnaireViewItem),
          composeViewQuestionnaireState,
        )

        if (!unit?.value.isNullOrBlank()) {
          UnitText(unitString = unit.value!!)
        }
      }
    }
  }

  /**
   * Returns the validation error message. If Questionnaire.Item.required is true, the error message
   * starts with `Required` text and the rest of the error message is placed on the next line.
   */
  @Composable
  private fun getValidationErrorMessage(questionnaireViewItem: QuestionnaireViewItem): String? =
    if (questionnaireViewItem.draftAnswer != null) {
      stringResource(validationMessageStringRes, *validationMessageStringResArgs)
    } else {
      when (val validationResult = questionnaireViewItem.validationResult) {
        is Invalid -> {
          validationResult.singleStringValidationMessage.let {
            if (
              questionnaireViewItem.questionnaireItem.required?.value == true &&
                questionnaireViewItem.questionViewTextConfiguration.showRequiredText
            ) {
              stringResource(Res.string.required_text_and_new_line) + it
            } else {
              it
            }
          }
        }

        else -> null
      }
    }
}
