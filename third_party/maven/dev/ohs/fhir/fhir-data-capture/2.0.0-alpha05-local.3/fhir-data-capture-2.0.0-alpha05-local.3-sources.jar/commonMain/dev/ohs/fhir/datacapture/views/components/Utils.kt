/*
 * Copyright 2025-2026 Open Health Stack Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dev.ohs.fhir.datacapture.views.components

import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import dev.ohs.fhir.datacapture.theme.QuestionnaireTheme
import dev.ohs.fhir.datacapture.views.QuestionnaireViewItem
import kotlin_fhir_data_capture.datacapture.generated.resources.Res
import kotlin_fhir_data_capture.datacapture.generated.resources.optional_helper_text
import kotlin_fhir_data_capture.datacapture.generated.resources.required
import org.jetbrains.compose.resources.stringResource

/**
 * Returns string identified by R.string.required if
 * [QuestionnaireViewItem.questionViewTextConfiguration.showRequiredText] and
 * [dev.ohs.fhir.model.r4.Questionnaire.Item.required] is true, or R.string.optional_text if
 * [QuestionnaireViewItem.questionViewTextConfiguration.showOptionalText] is true.
 */
@Composable
fun getRequiredOrOptionalText(questionnaireViewItem: QuestionnaireViewItem): String? {
  val requiredTextString = stringResource(Res.string.required)
  val optionalHelperTextString = stringResource(Res.string.optional_helper_text)

  // The strings are keys too: on the web, resources load asynchronously and are empty at first.
  return remember(questionnaireViewItem, requiredTextString, optionalHelperTextString) {
    when {
      (questionnaireViewItem.questionnaireItem.required?.value == true &&
        questionnaireViewItem.questionViewTextConfiguration.showRequiredText) -> {
        requiredTextString
      }

      (questionnaireViewItem.questionnaireItem.required?.value != true &&
        questionnaireViewItem.questionViewTextConfiguration.showOptionalText) -> {
        optionalHelperTextString
      }

      else -> {
        null
      }
    }
  }
}

/**
 * Read-only answers (e.g. calculated ones) stay disabled, so they can't be focused or edited, but are
 * shown as a highlighted value instead of Material's faded disabled look.
 */
@Composable
internal fun readOnlyTextFieldColors(): TextFieldColors =
  OutlinedTextFieldDefaults.colors(
    disabledTextColor = QuestionnaireTheme.colorScheme.onPrimaryContainer,
    disabledContainerColor = QuestionnaireTheme.colorScheme.primaryContainer,
    disabledBorderColor = Color.Transparent,
    disabledLabelColor = QuestionnaireTheme.colorScheme.onPrimaryContainer,
    disabledTrailingIconColor = QuestionnaireTheme.colorScheme.onPrimaryContainer,
    disabledSupportingTextColor = QuestionnaireTheme.colorScheme.onSurfaceVariant,
  )

/** Read-only answers in a semi-bold style, so a calculated value stands out. */
@Composable
internal fun readOnlyTextStyle(): TextStyle = LocalTextStyle.current.copy(fontWeight = FontWeight.SemiBold)

/**
 * Names an input after its question. The question is drawn as separate text above the field, so
 * without this a screen reader announces only "edit box" (or the date format).
 */
internal fun Modifier.questionLabel(questionnaireViewItem: QuestionnaireViewItem): Modifier =
  questionnaireViewItem.questionText?.text?.takeIf { it.isNotBlank() }?.let { question ->
    semantics { contentDescription = question }
  } ?: this
